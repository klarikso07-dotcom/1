﻿import type { GameEvent, GameState } from './types'

const EVENT_POOL: GameEvent[] = [
  { type: 'expense', description: 'Сломался телефон, пришлось чинить', amount: 150, emoji: '📱' },
  { type: 'expense', description: 'Потерял деньги по дороге в школу', amount: 80, emoji: '😱' },
  { type: 'expense', description: 'Порвались кроссовки, купили новые', amount: 120, emoji: '👟' },
  { type: 'income', description: 'Нашёл монетку на улице', amount: 20, emoji: '🪙' },
  { type: 'income', description: 'Друг вернул долг', amount: 50, emoji: '🤝' },
  { type: 'income', description: 'Бабушка дала деньги на карманные расходы', amount: 100, emoji: '👵' },
]

export function shouldTriggerEvent(day: number, state: GameState): boolean {
  // срабатывает только один раз за игру, на днях 3-5
  const alreadyTriggered = state.history.some((h) => h.option.text.startsWith('__event'))
  if (alreadyTriggered) return false
  if (day < 3 || day > 5) return false
  return Math.random() < 0.3
}

export function getRandomEvent(): GameEvent {
  return EVENT_POOL[Math.floor(Math.random() * EVENT_POOL.length)]
}
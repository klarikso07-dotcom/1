import type { Scenario, GameDay } from './types'
import { scenarios } from './scenarios'

export function loadScenario(id: string): Scenario | null {
  return scenarios.find((s) => s.id === id) ?? null
}

export function getDay(scenario: Scenario, dayIndex: number): GameDay | null {
  return scenario.days[dayIndex] ?? null
}

export function getAllScenarios(): Scenario[] {
  return scenarios
}
import type { GameState } from './types'

export type Grade = 'S' | 'A' | 'B' | 'C' | 'D'

export interface ScoreResult {
  score: number
  grade: Grade
  message: string
  goalReached: boolean
}

export function calculateScore(state: GameState): ScoreResult {
  let score = state.score

  const goalReached = state.savings >= state.goal.amount

  // бонус за достижение цели
  if (goalReached) score += 30

  // бонус за остаток на балансе
  if (state.budget > 0) score += 10
  if (state.budget > 100) score += 10

  // штраф за импульсивные решения
  const badChoices = state.history.filter((h) => !h.option.isGoodChoice).length
  score -= badChoices * 5

  score = Math.max(0, score)

  let grade: Grade
  if (score >= 80) grade = 'S'
  else if (score >= 60) grade = 'A'
  else if (score >= 40) grade = 'B'
  else if (score >= 20) grade = 'C'
  else grade = 'D'

  const messages: Record<Grade, string> = {
    S: 'Ты настоящий финансовый гений! Все деньги под контролем 🏆',
    A: 'Отлично справился! Почти идеально 👏',
    B: 'Неплохо, но есть куда расти. В следующий раз будет лучше 💪',
    C: 'Многовато импульсивных трат. Подумай дважды перед покупкой 🤔',
    D: 'Деньги утекли как вода. Попробуй ещё раз! 😅',
  }

  return { score, grade, message: messages[grade], goalReached }
}
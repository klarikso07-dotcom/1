import weekOfMax from './week-of-max.json'
import hardWeek from './hard-week.json'
import type { Scenario } from '../types'

export const scenarios: Scenario[] = [
  weekOfMax as Scenario,
  hardWeek as Scenario,
]

export { weekOfMax, hardWeek }
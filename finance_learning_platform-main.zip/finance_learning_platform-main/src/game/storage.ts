import type { Grade } from './scoringEngine'

interface SavedProgress {
  bestGrades: Record<string, Grade>
  lastCharacterId: string | null
}

const KEY = 'kopilka-progress'

export function loadProgress(): SavedProgress {
  try {
    const raw = localStorage.getItem(KEY)
    return raw ? JSON.parse(raw) : { bestGrades: {}, lastCharacterId: null }
  } catch {
    return { bestGrades: {}, lastCharacterId: null }
  }
}

export function saveGrade(scenarioId: string, grade: Grade): void {
  const progress = loadProgress()
  const current = progress.bestGrades[scenarioId]
  const gradeOrder = ['D', 'C', 'B', 'A', 'S']
  if (!current || gradeOrder.indexOf(grade) > gradeOrder.indexOf(current)) {
    progress.bestGrades[scenarioId] = grade
    localStorage.setItem(KEY, JSON.stringify(progress))
  }
}

export function saveCharacter(characterId: string): void {
  const progress = loadProgress()
  progress.lastCharacterId = characterId
  localStorage.setItem(KEY, JSON.stringify(progress))
}

export function resetProgress(): void {
  localStorage.removeItem(KEY)
}
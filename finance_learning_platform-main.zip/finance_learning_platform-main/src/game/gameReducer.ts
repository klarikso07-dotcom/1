﻿import type { GameState, DecisionOption, GameEvent, Scenario, Character } from './types'

export type GameAction =
  | { type: 'START_GAME'; payload: { scenario: Scenario; character: Character } }
  | { type: 'MAKE_DECISION'; payload: DecisionOption }
  | { type: 'NEXT_DAY' }
  | { type: 'TRIGGER_EVENT'; payload: GameEvent }
  | { type: 'SAVE_TO_GOAL'; payload: number }
  | { type: 'RESET_GAME' }

export const initialState: GameState = {
  budget: 0,
  savings: 0,
  currentDay: 1,
  goal: { name: '', amount: 0 },
  scenario: null,
  character: null,
  history: [],
  score: 0,
  isGameOver: false,
}

export function gameReducer(state: GameState, action: GameAction): GameState {
  switch (action.type) {
    case 'START_GAME':
      return {
        ...initialState,
        scenario: action.payload.scenario,
        character: action.payload.character,
        budget: action.payload.scenario.startBudget,
        goal: action.payload.scenario.goal,
      }

    case 'MAKE_DECISION': {
      const option = action.payload
      const newBudget = state.budget - option.cost
      const scoreChange = option.isGoodChoice ? 10 : -5
      return {
        ...state,
        budget: newBudget,
        score: state.score + scoreChange,
        history: [...state.history, { day: state.currentDay, option }],
      }
    }

    case 'NEXT_DAY': {
      const isLast = state.scenario ? state.currentDay >= state.scenario.days.length : true
      return {
        ...state,
        currentDay: state.currentDay + 1,
        isGameOver: isLast,
      }
    }

    case 'TRIGGER_EVENT': {
      const event = action.payload
      const change = event.type === 'income' ? event.amount : -event.amount
      return {
        ...state,
        budget: state.budget + change,
      }
    }

    case 'SAVE_TO_GOAL': {
      const amount = action.payload
      if (amount > state.budget) return state
      return {
        ...state,
        budget: state.budget - amount,
        savings: state.savings + amount,
      }
    }

    case 'RESET_GAME':
      return { ...initialState }

    default:
      return state
  }
}
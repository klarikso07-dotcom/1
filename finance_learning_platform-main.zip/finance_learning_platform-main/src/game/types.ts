﻿export interface DecisionOption {
  text: string
  cost: number
  consequence: string
  isGoodChoice: boolean
}

export interface GameDay {
  situation: string
  emoji: string
  options: DecisionOption[]
}

export interface Goal {
  name: string
  amount: number
}

export interface Scenario {
  id: string
  title: string
  startBudget: number
  goal: Goal
  days: GameDay[]
}

export interface DecisionRecord {
  day: number
  option: DecisionOption
}

export interface Character {
  id: string
  name: string
  emoji: string
}

export interface GameState {
  budget: number
  savings: number
  currentDay: number
  goal: Goal
  scenario: Scenario | null
  character: Character | null
  history: DecisionRecord[]
  score: number
  isGameOver: boolean
}

export interface GameEvent {
  type: 'income' | 'expense'
  description: string
  amount: number
  emoji: string
}
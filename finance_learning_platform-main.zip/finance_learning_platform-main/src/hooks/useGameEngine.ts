﻿import { useReducer } from 'react'
import { gameReducer, initialState } from '../game/gameReducer'
import type { DecisionOption, GameEvent, Scenario, Character } from '../game/types'

export function useGameEngine() {
  const [state, dispatch] = useReducer(gameReducer, initialState)

  const startGame = (scenario: Scenario, character: Character) => {
    dispatch({ type: 'START_GAME', payload: { scenario, character } })
  }

  const makeDecision = (option: DecisionOption) => {
    dispatch({ type: 'MAKE_DECISION', payload: option })
  }

  const nextDay = () => {
    dispatch({ type: 'NEXT_DAY' })
  }

  const triggerEvent = (event: GameEvent) => {
    dispatch({ type: 'TRIGGER_EVENT', payload: event })
  }

  const saveToGoal = (amount: number) => {
    dispatch({ type: 'SAVE_TO_GOAL', payload: amount })
  }

  const resetGame = () => {
    dispatch({ type: 'RESET_GAME' })
  }

  return {
    state,
    startGame,
    makeDecision,
    nextDay,
    triggerEvent,
    saveToGoal,
    resetGame,
    isGameOver: state.isGameOver,
  }
}
import { useState, lazy, Suspense } from 'react'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import type { Character, GameState } from './game/types'
import { initialState } from './game/gameReducer'
import StartScreen from './components/StartScreen'
import LevelSelect from './components/LevelSelect'
import CharacterSelect from './components/CharacterSelect'

// ленивая загрузка тяжёлых экранов
const GameScreen = lazy(() => import('./components/GameScreen'))
const ResultScreen = lazy(() => import('./components/ResultScreen'))

function App() {
  const [character, setCharacter] = useState<Character | null>(null)
  const [scenarioId, setScenarioId] = useState('week-of-max')
  const [gameState, setGameState] = useState<GameState>(initialState)

  return (
    <BrowserRouter>
      <Suspense fallback={
        <div className="min-h-screen bg-indigo-500 flex items-center justify-center">
          <span className="text-6xl animate-bounce">🐷</span>
        </div>
      }>
        <Routes>
          <Route path="/" element={<StartScreen />} />
          <Route path="/levels" element={<LevelSelect onSelect={setScenarioId} />} />
          <Route path="/select" element={<CharacterSelect onSelect={setCharacter} />} />
          <Route
            path="/game"
            element={
              <GameScreen
                character={character}
                scenarioId={scenarioId}
                onGameEnd={(s) => setGameState(s)}
              />
            }
          />
          <Route path="/result" element={<ResultScreen gameState={gameState} />} />
        </Routes>
      </Suspense>
    </BrowserRouter>
  )
}

export default App
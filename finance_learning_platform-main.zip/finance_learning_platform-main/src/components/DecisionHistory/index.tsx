import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import type { DecisionRecord } from '../../game/types'

const DAY_NAMES = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс']

interface Props {
  history: DecisionRecord[]
}

export default function DecisionHistory({ history }: Props) {
  const [open, setOpen] = useState(false)

  return (
    <div className="w-full max-w-sm">
      <button
        onClick={() => setOpen(!open)}
        className="w-full bg-white/20 text-white font-bold py-3 rounded-2xl mb-2"
      >
        {open ? '▲' : '▼'} Разбор решений
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <div className="flex flex-col gap-2 pb-2">
              {history.map((record, i) => (
                <div
                  key={i}
                  className={`rounded-xl p-3 flex items-start gap-3 ${
                    record.option.isGoodChoice ? 'bg-green-500/20' : 'bg-red-500/20'
                  }`}
                >
                  <span className="text-xl mt-0.5">
                    {record.option.isGoodChoice ? '✅' : '❌'}
                  </span>
                  <div>
                    <div className="text-white/60 text-xs">{DAY_NAMES[record.day - 1]}</div>
                    <div className="text-white text-sm font-medium">{record.option.text}</div>
                    <div className="text-white/70 text-xs mt-0.5">{record.option.consequence}</div>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
import { motion } from 'framer-motion'
import { useNavigate } from 'react-router-dom'
import { getAllScenarios } from '../../game/ScenarioManager'

const LEVEL_EMOJIS = ['🌱', '🔥']
const LEVEL_LABELS = ['Лёгкий', 'Сложный']

interface Props {
  onSelect: (scenarioId: string) => void
}

export default function LevelSelect({ onSelect }: Props) {
  const navigate = useNavigate()
  const scenarios = getAllScenarios()

  return (
    <div className="min-h-screen bg-gradient-to-b from-indigo-500 to-purple-600 flex flex-col items-center justify-center p-6">
      <motion.h2
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-3xl font-bold text-white mb-2"
      >
        Выбери уровень
      </motion.h2>
      <p className="text-indigo-200 mb-10">Насколько ты готов?</p>

      <div className="flex flex-col gap-4 w-full max-w-sm">
        {scenarios.map((scenario, i) => (
          <motion.button
            key={scenario.id}
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.15 }}
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            onClick={() => {
              onSelect(scenario.id)
              navigate('/select')
            }}
            className="bg-white/20 hover:bg-white/30 text-white rounded-2xl p-5 text-left"
          >
            <div className="flex items-center gap-3 mb-2">
              <span className="text-4xl">{LEVEL_EMOJIS[i]}</span>
              <div>
                <div className="text-xs text-indigo-200">{LEVEL_LABELS[i]}</div>
                <div className="font-bold text-lg">{scenario.title}</div>
              </div>
              <div className="ml-auto flex gap-1">
                {[...Array(i + 1)].map((_, j) => (
                  <span key={j} className="text-yellow-400">⭐</span>
                ))}
              </div>
            </div>
            <p className="text-indigo-200 text-sm">
              Старт: {scenario.startBudget} ₽ · Цель: {scenario.goal.amount} ₽ на {scenario.goal.name}
            </p>
          </motion.button>
        ))}
      </div>
    </div>
  )
}
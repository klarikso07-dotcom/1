import { motion, AnimatePresence } from 'framer-motion'

const DAY_NAMES = ['Понедельник', 'Вторник', 'Среда', 'Четверг', 'Пятница', 'Суббота', 'Воскресенье']

interface Props {
  day: number
  budgetChange: number
  visible: boolean
}

export default function DayTransition({ day, budgetChange, visible }: Props) {
  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ y: '100%', opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: '-100%', opacity: 0 }}
          transition={{ duration: 0.4 }}
          className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-indigo-700"
        >
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="text-center"
          >
            <div className="text-6xl mb-4">📅</div>
            <h2 className="text-4xl font-bold text-white mb-2">
              {DAY_NAMES[(day - 1) % 7]}
            </h2>
            <p className="text-indigo-300 text-lg">День {day}</p>

            {budgetChange !== 0 && (
              <div className={`mt-6 text-2xl font-bold ${budgetChange < 0 ? 'text-red-400' : 'text-green-400'}`}>
                {budgetChange < 0 ? `−${Math.abs(budgetChange)} ₽` : `+${budgetChange} ₽`}
              </div>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
﻿import { motion } from 'framer-motion'
import type { DecisionOption } from '../../game/types'

interface Props {
  option: DecisionOption
  index: number
  budget: number
  onClick: () => void
}

export default function DecisionCard({ option, index, budget, onClick }: Props) {
  const disabled = option.cost > 0 && budget < option.cost

  return (
    <motion.button
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: index * 0.1 }}
      whileHover={{ scale: disabled ? 1 : 1.02 }}
      whileTap={{ scale: disabled ? 1 : 0.97 }}
      disabled={disabled}
      onClick={onClick}
      className={`p-4 rounded-2xl text-left shadow transition-all w-full ${
        disabled
          ? 'bg-white/10 text-white/40 cursor-not-allowed'
          : 'bg-white text-gray-900 hover:bg-yellow-50'
      }`}
    >
      <div className="font-bold text-base">{option.text}</div>
      {option.cost !== 0 && (
        <div className={`text-sm mt-1 font-medium ${option.cost < 0 ? 'text-green-600' : 'text-red-500'}`}>
          {option.cost < 0 ? `+${Math.abs(option.cost)} ₽` : `-${option.cost} ₽`}
        </div>
      )}
      {disabled && (
        <div className="text-xs mt-1 text-white/50">Не хватает денег</div>
      )}
    </motion.button>
  )
}
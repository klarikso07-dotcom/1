import { motion, AnimatePresence } from 'framer-motion'
import type { GameEvent } from '../../game/types'

interface Props {
  event: GameEvent | null
  onClose: () => void
}

export default function EventPopup({ event, onClose }: Props) {
  return (
    <AnimatePresence>
      {event && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-6"
        >
          <motion.div
            initial={{ scale: 0.7, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.7, opacity: 0 }}
            transition={{ type: 'spring', stiffness: 300 }}
            className="bg-white rounded-3xl p-8 text-center max-w-sm w-full shadow-2xl"
          >
            <div className="text-6xl mb-4">{event.emoji}</div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">Неожиданно!</h3>
            <p className="text-gray-600 mb-4">{event.description}</p>
            <div className={`text-3xl font-bold mb-6 ${event.type === 'expense' ? 'text-red-500' : 'text-green-500'}`}>
              {event.type === 'expense' ? `−${event.amount} ₽` : `+${event.amount} ₽`}
            </div>
            <button
              onClick={onClose}
              className="bg-indigo-500 hover:bg-indigo-600 text-white font-bold px-8 py-3 rounded-2xl w-full"
            >
              Понятно
            </button>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
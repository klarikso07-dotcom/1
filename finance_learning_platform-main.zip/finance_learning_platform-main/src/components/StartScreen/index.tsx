import { motion } from 'framer-motion'
import { useNavigate } from 'react-router-dom'

export default function StartScreen() {
  const navigate = useNavigate()

  return (
    <div className="min-h-screen bg-gradient-to-b from-indigo-500 to-purple-600 flex flex-col items-center justify-center p-6">
      <motion.div
        initial={{ opacity: 0, y: -40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="text-center"
      >
        <div className="text-8xl mb-4">🐷</div>
        <h1 className="text-4xl font-bold text-white mb-2">Копилка</h1>
        <p className="text-indigo-200 text-lg mb-10">
          Учись управлять деньгами — весело и без скуки!
        </p>
      </motion.div>

      <motion.button
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.4, duration: 0.4 }}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => navigate('/levels')}
        className="bg-yellow-400 hover:bg-yellow-300 text-gray-900 font-bold text-xl px-12 py-4 rounded-2xl shadow-lg"
      >
        Начать игру 🚀
      </motion.button>

      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.8 }}
        className="text-indigo-300 text-sm mt-8"
      >
        Банк Центр-Инвест
      </motion.p>
    </div>
  )
}
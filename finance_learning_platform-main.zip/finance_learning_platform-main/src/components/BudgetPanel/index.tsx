﻿import { motion,  } from 'framer-motion'
import type { Goal } from '../../game/types'

interface Props {
  budget: number
  savings: number
  goal: Goal
}

export default function BudgetPanel({ budget, savings, goal }: Props) {
  const progress = Math.min((savings / goal.amount) * 100, 100)

  const budgetColor =
    budget > 300 ? 'bg-green-400' : budget > 100 ? 'bg-yellow-400' : 'bg-red-400'

  return (
    <div className="flex flex-col gap-2">
      {/* баланс */}
      <div className={`${budgetColor} rounded-xl px-4 py-2 text-center`}>
        <div className="text-xs text-gray-700 font-medium">Кошелёк</div>
        <motion.div
          key={budget}
          initial={{ scale: 1.3 }}
          animate={{ scale: 1 }}
          transition={{ type: 'spring', stiffness: 300 }}
          className="text-gray-900 font-bold text-lg"
        >
          {budget} ₽
        </motion.div>
      </div>

      {/* копилка */}
      <div className="bg-white/20 rounded-xl p-3">
        <div className="flex justify-between text-white text-xs mb-1">
          <span>🐷 Копилка</span>
          <span>{savings} / {goal.amount} ₽</span>
        </div>
        <div className="bg-white/30 rounded-full h-2">
          <motion.div
            className="bg-yellow-400 h-2 rounded-full"
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.5 }}
          />
        </div>
        <div className="text-white/60 text-xs mt-1 text-center">{goal.name}</div>
      </div>
    </div>
  )
}
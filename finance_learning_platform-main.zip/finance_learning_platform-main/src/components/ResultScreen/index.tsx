﻿import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import type { GameState } from '../../game/types'
import { calculateScore } from '../../game/scoringEngine'
import DecisionHistory from '../DecisionHistory'

interface Props {
  gameState: GameState
}

const GRADE_COLORS = {
  S: 'text-yellow-400',
  A: 'text-green-400',
  B: 'text-blue-400',
  C: 'text-orange-400',
  D: 'text-red-400',
}

export default function ResultScreen({ gameState }: Props) {
  const navigate = useNavigate()
  const [showConfetti, setShowConfetti] = useState(false)
  const result = calculateScore(gameState)

  useEffect(() => {
    if (result.goalReached) setShowConfetti(true)
  }, [])

  return (
    <div className="min-h-screen bg-gradient-to-b from-indigo-600 to-purple-700 flex flex-col items-center justify-center p-6">

      <AnimatePresence>
        {showConfetti && (
          <div className="fixed inset-0 pointer-events-none overflow-hidden">
            {[...Array(20)].map((_, i) => (
              <motion.div
                key={i}
                initial={{ y: -20, x: Math.random() * window.innerWidth, opacity: 1 }}
                animate={{ y: window.innerHeight + 20, opacity: 0 }}
                transition={{ duration: 2 + Math.random() * 2, delay: Math.random() * 1 }}
                className="absolute text-2xl"
              >
                {['🎉', '⭐', '🌟', '💰', '🎊'][Math.floor(Math.random() * 5)]}
              </motion.div>
            ))}
          </div>
        )}
      </AnimatePresence>

      <motion.div
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ type: 'spring', stiffness: 200, delay: 0.2 }}
        className={`text-9xl font-black mb-2 ${GRADE_COLORS[result.grade]}`}
      >
        {result.grade}
      </motion.div>

      <motion.p
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="text-white text-center text-lg mb-6 px-4"
      >
        {result.message}
      </motion.p>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.7 }}
        className="bg-white/20 rounded-2xl p-5 w-full max-w-sm mb-4"
      >
        <div className="flex justify-between text-white mb-3">
          <span>Осталось в кошельке</span>
          <span className="font-bold">{gameState.budget} ₽</span>
        </div>
        <div className="flex justify-between text-white mb-3">
          <span>Накоплено</span>
          <span className="font-bold">{gameState.savings} ₽</span>
        </div>
        <div className="flex justify-between text-white mb-3">
          <span>Цель</span>
          <span className="font-bold">{gameState.goal.amount} ₽</span>
        </div>
        <div className="flex justify-between text-white">
          <span>Очки</span>
          <span className="font-bold">{result.score}</span>
        </div>
        {result.goalReached && (
          <div className="mt-4 text-center text-yellow-300 font-bold text-lg">
            🎉 Накопил на {gameState.goal.name}!
          </div>
        )}
      </motion.div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.9 }}
        className="w-full max-w-sm flex flex-col gap-3"
      >
        <DecisionHistory history={gameState.history} />
        <button
          onClick={() => navigate('/')}
          className="bg-yellow-400 hover:bg-yellow-300 text-gray-900 font-bold py-4 rounded-2xl text-lg w-full"
        >
          Переиграть 🔄
        </button>
      </motion.div>
    </div>
  )
}
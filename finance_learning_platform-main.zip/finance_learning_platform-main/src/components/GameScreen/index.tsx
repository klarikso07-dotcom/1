﻿import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import type { Character, DecisionOption, GameEvent, GameState } from '../../game/types'
import { useGameEngine } from '../../hooks/useGameEngine'
import { loadScenario } from '../../game/ScenarioManager'
import { shouldTriggerEvent, getRandomEvent } from '../../game/events'
import BudgetPanel from '../BudgetPanel'
import DecisionCard from '../DecisionCard'
import DayTransition from '../DayTransition'
import EventPopup from '../EventPopup'

interface Props {
  character: Character | null
  scenarioId: string
  onGameEnd: (state: GameState) => void
}

export default function GameScreen({ character, scenarioId, onGameEnd }: Props) {
  const navigate = useNavigate()
  const { state, startGame, makeDecision, nextDay, triggerEvent, isGameOver } = useGameEngine()
  const [showTransition, setShowTransition] = useState(false)
  const [budgetChange, setBudgetChange] = useState(0)
  const [activeEvent, setActiveEvent] = useState<GameEvent | null>(null)
  const [feedback, setFeedback] = useState<{ text: string; good: boolean } | null>(null)

  useEffect(() => {
    const scenario = loadScenario(scenarioId)
    if (scenario && character) startGame(scenario, character)
  }, [])

  useEffect(() => {
    if (isGameOver) {
      onGameEnd(state)
      navigate('/result')
    }
  }, [isGameOver])

  useEffect(() => {
    if (state.currentDay > 1 && shouldTriggerEvent(state.currentDay, state)) {
      setActiveEvent(getRandomEvent())
    }
  }, [state.currentDay])

  const handleEventClose = () => {
    if (activeEvent) triggerEvent(activeEvent)
    setActiveEvent(null)
  }

  const handleDecision = (option: DecisionOption) => {
    makeDecision(option)
    setBudgetChange(-option.cost)
    setFeedback({ text: option.consequence, good: option.isGoodChoice })
    setTimeout(() => setFeedback(null), 1500)
    setShowTransition(true)
    setTimeout(() => {
      setShowTransition(false)
      nextDay()
    }, 1800)
  }

  const currentDayData = state.scenario?.days[state.currentDay - 1]
  if (!currentDayData) return null

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-500 to-indigo-600 flex flex-col p-4">
      <DayTransition day={state.currentDay} budgetChange={budgetChange} visible={showTransition} />
      <EventPopup event={activeEvent} onClose={handleEventClose} />

      <div className="flex items-center justify-between mb-4">
        <div className="bg-white/20 rounded-xl px-4 py-2">
          <span className="text-white font-bold">
            День {state.currentDay} / {state.scenario?.days.length}
          </span>
        </div>
        <span className="text-4xl">{state.character?.emoji}</span>
      </div>

      <div className="mb-4">
        <BudgetPanel budget={state.budget} savings={state.savings} goal={state.goal} />
      </div>

      <motion.div
        key={state.currentDay}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white/20 rounded-2xl p-5 mb-4 text-center"
      >
        <div className="text-5xl mb-3">{currentDayData.emoji}</div>
        <p className="text-white text-lg leading-relaxed">{currentDayData.situation}</p>
      </motion.div>

      <AnimatePresence>
        {feedback && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0 }}
            className={`rounded-2xl p-3 mb-4 text-center font-bold ${
              feedback.good ? 'bg-green-400 text-green-900' : 'bg-red-400 text-red-900'
            }`}
          >
            {feedback.good ? '👍 ' : '👎 '}{feedback.text}
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex flex-col gap-3 mt-auto">
        {currentDayData.options.map((option, i) => (
          <DecisionCard
            key={i}
            option={option}
            index={i}
            budget={state.budget}
            onClick={() => handleDecision(option)}
          />
        ))}
      </div>
    </div>
  )
}
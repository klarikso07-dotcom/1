import { useState } from 'react'
import { motion } from 'framer-motion'
import { useNavigate } from 'react-router-dom'
import type { Character } from '../../game/types'

const CHARACTERS: Character[] = [
  { id: 'max', name: 'Макс', emoji: '🧒' },
  { id: 'anya', name: 'Аня', emoji: '👧' },
  { id: 'dima', name: 'Дима', emoji: '🧑' },
]

interface Props {
  onSelect: (character: Character) => void
}

export default function CharacterSelect({ onSelect }: Props) {
  const [selected, setSelected] = useState<Character | null>(null)
  const navigate = useNavigate()

  const handleStart = () => {
    if (!selected) return
    onSelect(selected)
    navigate('/game')
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-indigo-500 to-purple-600 flex flex-col items-center justify-center p-6">
      <motion.h2
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-3xl font-bold text-white mb-2"
      >
        Выбери персонажа
      </motion.h2>
      <p className="text-indigo-200 mb-10">За кого будешь играть?</p>

      <div className="flex gap-6 mb-10">
        {CHARACTERS.map((char, i) => (
          <motion.button
            key={char.id}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            whileHover={{ scale: 1.08 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setSelected(char)}
            className={`flex flex-col items-center p-6 rounded-2xl shadow-lg transition-colors ${
              selected?.id === char.id
                ? 'bg-yellow-400 text-gray-900'
                : 'bg-white/20 text-white hover:bg-white/30'
            }`}
          >
            <span className="text-6xl mb-3">{char.emoji}</span>
            <span className="font-bold text-lg">{char.name}</span>
          </motion.button>
        ))}
      </div>

      <motion.button
        whileHover={{ scale: selected ? 1.05 : 1 }}
        whileTap={{ scale: selected ? 0.95 : 1 }}
        onClick={handleStart}
        disabled={!selected}
        className={`font-bold text-xl px-12 py-4 rounded-2xl shadow-lg transition-all ${
          selected
            ? 'bg-yellow-400 hover:bg-yellow-300 text-gray-900'
            : 'bg-white/20 text-white/40 cursor-not-allowed'
        }`}
      >
        {selected ? `Играть за ${selected.name} 🚀` : 'Выбери персонажа'}
      </motion.button>
    </div>
  )
}